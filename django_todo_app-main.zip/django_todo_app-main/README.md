# django_todo_app
This Todo App built with Django is a great to learn how to implement CRUD operations in Django.
